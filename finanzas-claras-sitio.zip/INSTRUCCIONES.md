# Instrucciones para publicar tu sitio "Finanzas Claras"

## 1. Publicar gratis con GitHub Pages
1. Crea cuenta gratis en https://github.com
2. Crea un repositorio nuevo, público, llamado por ejemplo `finanzas-claras`
3. Sube TODOS los archivos de esta carpeta (index.html, style.css, robots.txt, sitemap.xml, ads.txt y la carpeta pages/) a ese repositorio
4. Ve a **Settings > Pages** del repositorio, y en "Source" elige la rama `main` y carpeta `/root`
5. En unos minutos tu sitio estará en: `https://TU-USUARIO.github.io/finanzas-claras/`

## 2. IMPORTANTE: actualiza tu dominio real en el código
Antes de publicar, abre `generate.py`, cambia la línea:
```
DOMAIN = "https://TU-DOMINIO-AQUI.com"
```
por tu URL real (ej. `https://tuusuario.github.io/finanzas-claras`), y vuelve a correr `python3 generate.py`. Esto es lo que usan sitemap.xml, robots.txt y las etiquetas canonical — sin esto Google puede indexar mal el sitio.

## 3. Sobre el dominio propio
No existe hoy un dominio .com/.net gratis y confiable (los servicios como Freenom que lo ofrecían fueron cerrados en 2025). Si más adelante quieres verte más profesional:
- Namecheap, Porkbun o Google Domains (vía Squarespace) ofrecen dominios .com desde ~$1-12 el primer año
- Puedes conectar ese dominio propio a tu GitHub Pages gratis siguiendo su guía de "Custom domain"

## 4. Google Search Console (para pedir indexación)
1. Entra a https://search.google.com/search-console
2. Agrega tu propiedad (la URL de GitHub Pages o tu dominio propio)
3. Verifica la propiedad (por meta tag HTML, que puedes pegar en el `<head>` de index.html, o por archivo HTML que Google te da para subir)
4. Una vez verificado, ve a **Sitemaps** y envía: `sitemap.xml` (ej. `https://tusitio.com/sitemap.xml`)
5. Opcional: usa la herramienta "Inspección de URLs" para cada página y pulsa "Solicitar indexación" manualmente en las más importantes

## 5. Google AdSense
1. Entra a https://www.google.com/adsense
2. Solicita tu cuenta con la URL de tu sitio ya publicado (necesitas contenido visible, no en construcción)
3. Google revisa el sitio (puede tardar días o semanas) — necesitas contenido original, política de privacidad, y tráfico real es un plus
4. Una vez aprobado, te dan tu `data-ad-client` (ca-pub-XXXXXXXXXXXXXXXX)
5. Reemplaza `ca-pub-XXXXXXXXXXXXXXXX` en TODAS las páginas (o mejor, vuelve a correr `generate.py` tras editar `ADSENSE_HEAD` y `AD_SLOT` en el script) y en `ads.txt`

## 6. Recomendación importante
AdSense suele rechazar sitios nuevos sin: política de privacidad, página "Acerca de", y contenido suficiente. Antes de solicitar AdSense, considera agregar una página de privacidad simple (puedo generártela si quieres).
